
<div class="container">
    <?= form_open_multipart();?>
        <legend>Ubah Data Penduduk</legend>
        <input type="hidden" name="id" value="<?= $penduduk['id']; ?>">
        <div class="mb-3">
            <label for="nik" class="form-label">nik</label>
            <input type="text" class="form-control" id="nik" name="nik" value="<?= $penduduk['nik']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nik'); ?></div>
        </div>
        <div class="row">
            <div class="col">
              <label for="formFile" class="form-label">Foto</label>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="mb-3">
                    <img src="<?= base_url('assets/foto/') . $penduduk['foto']; ?>"  id="formFile" class="img-thumbnail" width="225" height="330">
                    <input class="form-control" type="file" id="formFile" name="image" value="<?= $penduduk['foto']; ?>" style="width : 500px;" require>
                    <div class="form-text text-danger"><?= form_error('image'); ?></div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $penduduk['nama']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        
        <div class="mb-3">
            <label for="bansos" class="form-label">bansos</label>
            <select class="form-select" id="bansos" name="bansos" style="width : 500px;">
                <option selected value="<?= $penduduk['id_bansos']; ?>"><?= $penduduk['bansos']; ?></option>
            <?php foreach( $bansos as $ban ) : ?>
                <option value="<?= $ban['id']; ?>"><?= $ban['bansos']; ?></option>
            <?php endforeach; ?>
            </select>
            <div class="form-text text-danger"><?= form_error('bansos'); ?></div>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= $penduduk['email']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('email'); ?></div>
        </div>
        <div class="mb-3">
            <label for="hp" class="form-label">Hp</label>
            <input type="text" class="form-control" id="hp" name="hp" value="<?= $penduduk['hp']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('hp'); ?></div>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" style="width : 500px;"><?= $penduduk['alamat']; ?></textarea>
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>