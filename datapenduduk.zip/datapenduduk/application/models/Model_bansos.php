<?php
class Model_bansos extends CI_Model 
{
    public function getAllbansos()
    {
        return $query = $this->db->get('bansos')->result_array();
    }

    public function Tambahbansos()
    {
        $data = [
            "bansos" => $this->input->post('bansos', true)
        ];

        $this->db->insert('bansos', $data);
    }

    public function Ubahbansos()
    {
        $data = [
            "bansos" => $this->input->post('bansos', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('bansos', $data);
    }

    public function hapusBansos($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('bansos');
    }

    public function getBansosById($id)
    {
        return $this->db->get_where('bansos', ['id' => $id])->row_array();
    }

    public function Caribansos()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('bansos', $keyword);
        return $this->db->get('bansos')->result_array();
    }
}

?>