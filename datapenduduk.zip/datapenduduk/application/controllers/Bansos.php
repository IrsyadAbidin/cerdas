<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bansos extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_bansos');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Bansos';

        $data['bansos'] = $this->Model_bansos->getAllBansos();
        if( $this->input->post('keyword') ) {
            $data['bansos'] = $this->Model_bansos->Caribansos();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('bansos/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('bansos', 'Bansos', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Bansos';

            $this->load->view('templates/header.php', $data);
            $this->load->view('bansos/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_bansos->Tambahbansos();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('bansos');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('bansos', 'Bansos', 'trim|required');
        $data['bansos'] = $this->Model_bansos->getBansosById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Bansos';

            $this->load->view('templates/header.php', $data);
            $this->load->view('bansos/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_bansos->Ubahbansos();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('bansos');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_bansos->hapusbansos($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('bansos');
    }
}