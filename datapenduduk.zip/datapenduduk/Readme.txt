
This resource has been created by Oussama Afellad for PremiumFreebies.eu

TERMS OF USE:


All resources made available on Premium Freebies, including but not limited to, icons, images, brushes, shapes, layer styles, layered PSD's, patterns, textures, web elements and themes are free for use in both personal and commercial projects.



You may freely use our resources, without restriction, in software programs, web templates and other materials intended for sale or distribution. 
No attribution or backlinks are required, but any form of spreading the word is always appreciated!



You are not permitted to make the resources found on Premium Freebies available for distribution elsewhere without prior consent.


